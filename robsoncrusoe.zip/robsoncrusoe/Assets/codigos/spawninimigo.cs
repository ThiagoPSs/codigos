﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawninimigo : MonoBehaviour
{
   // [SerializeField] para acessar o prefab
    private GameObject Cubo;
    int QuantidadeInimigos;
    bool cheio;
  

    // Update is called once per frame
    void Update()
    {
        
    }
}
